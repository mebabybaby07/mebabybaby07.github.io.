<!DOCTYPE html>

<html>
<head>
<meta charset="utf-8"/>
<title>"歡迎來到新人婚禮準備溝通"</title>


<body bgcolor="#e6e6fa" text="#0000cd">
  
<?php
  session_start(); 
  $userphone=$_SESSION["userphone"];
  //$usergender=$_SESSION["usergender"];
  
  if(isset($_GET["delete"])){   //選取"我要刪除"
    $link =@mysqli_connect('localhost','root','1234','meeting');
    mysqli_query($link,'SET NAMES utf8');
    $sql="UPDATE user SET pair='',anophone='' WHERE phone='$userphone'";  //刪除使用者的另一伴電話與組數
	mysqli_query($link,$sql);   
  }else if(isset($_GET["reset"])){ //選取"我要修改"
	?><h3>請填入新另一伴的資料</h3>

    <form name="resetano" method="get" action="reconnect.php">
	<font face="DFKai-sb">新另一伴的電話號碼:</font>
		<input type="text" name="phone" size="12"><br/>
    <br/>
	<input type="submit" name="resetano" value="修改" >
	</form> 
	<?php
  }else if($_GET["add"]){          //選取"新增"
	$phone=$_GET["phone"];
    if($phone !=""){
	  $link =@mysqli_connect('localhost','root','1234','meeting');
      mysqli_query($link,'SET NAMES utf8');
	
	  $sql = "SELECT * FROM user WHERE phone='$phone'";      //查詢另一伴是否有註冊
	  $result = mysqli_query($link,$sql);  
	  $num=mysqli_num_rows($result);
	  if($num>0){
	     while($row = mysqli_fetch_assoc($result)){	  
              if($row["anophone"]==$userphone||$row["anophone"]==" "){               //檢查另一伴的另一伴號碼為 自己或是空值
				$sql1="SELECT * FROM user WHERE pair=(SELECT MAX(pair) FROM user)";			
			    $result1= mysqli_query($link,$sql1);
			    while($row1 = mysqli_fetch_array($result1,MYSQLI_ASSOC)){
					  $maxpair=$row1["pair"];
			    }
			    $setpair=$maxpair+1;
			    $sql2="UPDATE user SET pair='$setpair',anophone='$phone' WHERE phone='$userphone'";  //給予組數
	            mysqli_query($link,$sql2);
                $sql3="UPDATE user SET pair='$setpair',anophone='$userphone' WHERE phone='$phone'";
	            mysqli_query($link,$sql3);
                echo "新增完畢~";				
             }else{	            
	              echo "<center><font color='red'>";
	              echo "此手機號碼並非與您配對";
	              echo "</font>";
	          }
         }  
	 }else{
		 echo "此電話並無人註冊，請再次確認電話號碼";
	 }   		
    } 
   }  

  

  ?>
  </body>
  </head>
  </html>