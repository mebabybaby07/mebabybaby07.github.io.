<?php //使用者登入表單?>
<!DOCTYPE html>

<html>
<head>
<meta charset="utf-8"/>
<title>"使用者登入"</title>
</head>

<body bgcolor="#e6e6fa" text="#0000cd">
<h3>使用者登入</h3>
<?php 
      if(isset($_GET["hasregistered"])){
		   echo "<center><font color='red'>";	
           echo "此電話已註冊過，請重新登入";
	       echo "</font>";
	  }
 ?>
    <form name="login" method="get" action="login.php">
	<font face="DFKai-sb">電話號碼:</font>
		                            <input type="text" name="phone" size="12"><br/>
    <br/>
	<font face="DFKai-sb">密碼:</font>
		                       <input type="password" name="password" size="12"><br/>
	<br/>
	<input type="submit" name="login" value="登入" >
	</form>		
</body>