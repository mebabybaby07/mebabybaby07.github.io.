<?php
//echo "兩人分析結果";

$link =@mysqli_connect('localhost','root','1234','meeting');
mysqli_query($link,'SET NAMES utf8');
session_start();
$userphone = $_SESSION["userphone"]; 
$anophone = $_SESSION["anophone"];

$sql="SELECT A,B,C,D,E,F,G,H,I,J FROM twoanswer WHERE phone=$userphone";
$result=mysqli_query($link,$sql);
$row=mysqli_fetch_row($result);

$seq=array();
$num=0;      //項目數目
for($i=1; $i<=10; $i++){
	if($row[$i-1]!=0){
		$sql2="SELECT itemname FROM itemnum WHERE itemnum='$i'";
		$result2=mysqli_query($link,$sql2);
		$row2=mysqli_fetch_row($result2);
		$seq["$row2[0]"]=$row[$i-1];
		$num++;
	}
}
arsort($seq);
//print_r($seq);

$sql2="SELECT * FROM user WHERE phone=$userphone";      //找出使用者性別,姓名
$result2=mysqli_query($link,$sql2);
$row2=mysqli_fetch_assoc($result2);
$sql3="SELECT * FROM user WHERE phone=$anophone";      //找出另一伴性別,姓名，
$result3=mysqli_query($link,$sql3);
$row3=mysqli_fetch_assoc($result3);

if($row2["gender"]==1){
	echo $row2["name"]."小姐姐您好，感謝您填寫我們的問卷!";?></br><?php
	if($row3["gender"]==1){
		echo "我們已將您與".$row3["name"]."小姐的結果分析完畢了!";
	}else{
		echo "我們已將您與".$row3["name"]."先生的結果分析完畢了!";
	}
}else{
	echo $row2["name"]."小哥哥您好，感謝您填寫我們的問卷!我們已將您的結果分析完畢了!";?></br><?php
	if($row3["gender"]==1){
		echo "我們已將您與".$row3["name"]."小姐的結果分析完畢了!";
	}else{
		echo "我們已將您與".$row3["name"]."先生的結果分析完畢了!";
	}
}
?></br><?php

$it=array_keys($seq);
$j=$num;
for($i=1; $i<=$num; $i++){
	echo "第".$i."順位為".$it[$j-1];
	$j--;
}

?>
