<?php //使用者使用功能選擇?>
<!DOCTYPE html>

<html>
<head>
<meta charset="utf-8"/>
<title>"功能選擇"</title>
</head>

<body bgcolor="#e6e6fa" text="#0000cd">
  
    <h3>歡迎再次回來，請選擇您要執行的功能</h3>
    
	<?php  //判斷兩人都有選擇個人項目才出現此按鈕 
	    
	    session_start();
		$userphone=$_SESSION["userphone"];
		$link =@mysqli_connect('localhost','root','1234','meeting');
        mysqli_query($link,'SET NAMES utf8');
		
		$sql = "SELECT pair FROM user WHERE phone=$userphone";  //找到使用者組數
        $result = mysqli_query($link,$sql);
		$row=mysqli_fetch_row($result);	
        $_SESSION["pair"]=$row[0];		
		
		$sql1 = "SELECT anophone FROM user WHERE phone=$userphone";  //找到使用者另一伴電話
        $result1 = mysqli_query($link,$sql1);
	    $row1=mysqli_fetch_row($result1);
        $_SESSION["anophone"]=$row1[0];		
		
		$sql2 = "SELECT pair FROM user WHERE phone=$row1[0]";  //找到使用者另一伴組數
        $result2 = mysqli_query($link,$sql2);
	    $row2=mysqli_fetch_row($result2);
		
		if($row[0]!=null && $row2[0]!=null && $row[0]==$row2[0]){
		
		//判斷自己是否有選擇項目
		$sql3 = "SELECT A,B,C,D,E,F,G,H,I,J FROM user WHERE phone='$userphone'";
        $result3 = mysqli_query($link,$sql3);
		$row3=mysqli_fetch_row($result3);
		$itemqua=0;
		for($i=0;$i<10;$i++){
			if($row3[$i]!=0){
			  $itemqua++;
			}
		}
		echo "您目前選的項目總數:".$itemqua."    ";
		
		//判斷另一伴是否有選擇項目
		$sql4 = "SELECT A,B,C,D,E,F,G,H,I,J FROM user WHERE anophone=$userphone";
		$result4 = mysqli_query($link,$sql4);
		$row4=mysqli_fetch_row($result4);
		$itemquaa=0;
		for($i=0;$i<10;$i++){
			if($row4[$i]!=0){
			  $itemquaa++;
			}
		}
		echo "另一伴選的總數:".$itemquaa;
		
		if($itemqua>0 && $itemquaa>0){
			
		?>	<input type="submit" name="twoitemselect" value="作答雙人填寫項目" onclick="location.href= ('http://localhost:8080/meeting/showquestion.php')"/>  <?php //進入登入頁面?>
		<?php
		}else{
		     ?>
		<br>
		要兩人都填選才能進行兩人的題目填寫喔~~~
		<?php	
		}		
	    }
		//判斷是否已經做過問卷
		$sql5 = "SELECT A,B,C,D,E,F,G,H,I,J FROM twoanswer WHERE phone='$userphone'";
        $result5 = mysqli_query($link,$sql5);
		$row5=mysqli_fetch_row($result5);
		$ans=0;
		for($i=0;$i<10;$i++){
			if($row5[$i]!=0){
			  $ans++;
			}
		}
		if($ans>0){?>
			<input type="submit" name="twoana" value="查看雙人分析結果" onclick="location.href= ('http://localhost:8080/meeting/twoanalysis.php')"/>  <?php //進入雙人分析結果頁面?>	
		    </br>
		<?php
		}

		//顯示使用者目前選擇的項目
		//顯示user資料表ABC那些欄位為1
		//顯示的同時，抓itemnum表的數值是多少
		$sql3 = "SELECT A,B,C,D,E,F,G,H,I,J FROM user WHERE phone='$userphone'";
        $result3 = mysqli_query($link,$sql3);
		$row3=mysqli_fetch_row($result3);
		$i=0;
		while($meta=mysqli_fetch_field($result3)){    //一次顯示一個欄位名
			if($row3[$i]!=0){
			   //echo $meta->name."+";
			   $sq="SELECT itemname FROM itemnum WHERE itemnum=$i+1";
		       $resul = mysqli_query($link,$sq);
               $ro=mysqli_fetch_row($resul);
		       echo $ro[0].",";
			   $i++;
			}else{$i++;}
		}
		echo "為您目前所選擇的分析項目";?>
	<input type="submit" name="itemselect" value="新增個人填寫項目" onclick="location.href= ('http://localhost:8080/meeting/itemselect.php')"/>  <?php //進入登入頁面?>
    <br>
	</br>
	
    <input type="submit" name="connect" value="編輯另一伴資料" onclick="location.href= ('http://localhost:8080/meeting/anoconnect.php')"/>    <?php //進入執行配對之畫面?>

  
</body>