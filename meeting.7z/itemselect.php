<?php //使用者選擇項目?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>婚備項目選擇</title>
<style>
   body{
	   background-image:url(12345.jpg);
	   background-repeat:no-repeat;
	   background-position:center;
   }
</style>
</head>
<body bgcolor="#e6e6fa" text="#0000cd"> 
<?php
    //未解決問題:Notice: Undefined offset: 3 in /home/raj/public_html/viewgallery.php on line 38
	
	if(isset($_GET["itemchoice"])){
		session_start();
		$link =@mysqli_connect('localhost','root','1234','meeting');
        mysqli_query($link,'SET NAMES utf8');
		$sql = "SELECT * FROM itemnum ";
        $result = mysqli_query($link,$sql);
		$sql1 = "SELECT * FROM user ";
		$result1 = mysqli_query($link,$sql1);
        $total_records=mysqli_num_rows($result);
		$item = $_GET ["item"]; 
		$_SESSION["item"]=$item;
		$select_item=0;
		$userphone=$_SESSION["userphone"];
		  
		for($i=1; $i<$total_records+1; $i++){      //判斷共選了幾個項目
            if(isset($item[$i-1])){
				$select_item++;
				$_SESSION["select_item"]=$select_item;
			}
        }
		
	    $h=0;
		$i=0;
		while($meta = mysqli_fetch_field($result1)){                             //將選擇的題目記錄自user資料表內
			if($h==($item[$i]+5)){
				//echo $meta->name."+";
				$sql2="UPDATE user SET $meta->name='1' WHERE phone=$userphone"; 
				mysqli_query($link,$sql2);
				$i++;
			}else{
				if($h>=6){
				$sql2="UPDATE user SET $meta->name='0' WHERE phone=$userphone"; 
				mysqli_query($link,$sql2);
				}
			}
			$h++;
		}
        //詢問進行個人分析或是回到功能選擇
		?>
		<center><font color='red'>
		項目選擇成功!!<br/>
		</font>
		若您想進行個人分析，請按"個人分析"，或是點擊"返回"，返回功能選擇頁~<br/>
		<form name="personitemselect" method="get" action="showquestion.php">
		<input type="submit" name="personitemselect" value="個人分析" onclick="location.href= ('http://localhost:8080/meeting/showquestion.php')"/>
		</form>
		<input type="submit" name="itemselect" value="返回" onclick="location.href= ('http://localhost:8080/meeting/functionselect.php')"/>
	    
	<?php
	}else{
	?>  
   <h1>婚備項目選擇</h1>
   <h4>每項6題</h4>
   <form name="itemchoice" method="get" action="itemselect.php">
   <?php
     $link =@mysqli_connect('localhost','root','1234','meeting');
	 mysqli_query($link,'SET NAMES utf8');
	 $sql = "SELECT * FROM itemnum ";
	 $result = mysqli_query($link,$sql); 
     $total_records=mysqli_num_rows($result);
	 
     for($i=1; $i<$total_records+1; $i++){
		 $row=mysqli_fetch_row($result);
   ?> 
		 <input type="checkbox" name="item[]" value="<?php echo $i ?>"> <?php echo $row[0] ?> <br>	          		   
   <?php
	 }
   ?>   
    <input type="submit" name="itemchoice" value="確認" >   
	</form>
	<?php 
	}
	?>
</body>
</html>