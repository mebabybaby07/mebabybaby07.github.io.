<?php //使用者連結另一伴?>
<!DOCTYPE html>

<html>
<head>
<meta charset="utf-8"/>
<title>"建立另一伴連結"</title>
</head>

<body bgcolor="#e6e6fa" text="#0000cd">
<?php
  session_start(); 
  $userphone=$_SESSION["userphone"];
  $link =@mysqli_connect('localhost','root','1234','meeting');
  mysqli_query($link,'SET NAMES utf8');
  
  $sql="SELECT * FROM user WHERE phone=$userphone";
  $result = mysqli_query($link,$sql);  
  $row = mysqli_fetch_assoc($result);
  if($row["pair"]==null){   //目前沒有配對
     echo "您目前沒有配對的對象 ";
	  ?><h3>請填入另一伴的資料</h3>

    <form name="anoconnect" method="get" action="connect.php">
	<font face="DFKai-sb">另一伴的電話號碼:</font>
		<input type="text" name="phone" size="12"><br/>
    <br/>
	<input type="submit" name="add" value="新增" >
	</form>
<?php 
  }else{   //目前已有配對，顯示另一伴，可選擇刪除或修改
	  $anophone=$row["anophone"];
	  $link =@mysqli_connect('localhost','root','1234','meeting');
      mysqli_query($link,'SET NAMES utf8');
	  $sql1="SELECT * FROM user WHERE phone=$anophone";
      $result1 = mysqli_query($link,$sql1); 
      $row1 = mysqli_fetch_assoc($result1);
      echo $userphone;	  
	  echo "您目前的另一伴為: ".$row1["name"]; ?></br><?php 
	  echo "手機號碼為: ".$row1["phone"];
	  ?>
	  </br>
	  <form name="anoconnect" method="get" action="connect.php">
	  <input type="submit" name="delete" value="我要刪除" OnClick="return confirm('確定要解除與他的聯結嗎?');">
	  <input type="submit" name="reset" value="我要修改" > 
	  </form>
	  <?php
  }
?>




		
</body>