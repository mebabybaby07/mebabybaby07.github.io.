 <?php //使用者註冊表單?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>使用者註冊</title>
<style>
   body{
	   background-image:url(12345.jpg);
	   background-repeat:no-repeat;
	   background-position:center;
   }

</style>
</head>
<body bgcolor="#e6e6fa" text="#0000cd">  
   <h1>使用者註冊</h1> 
   <form name="login" method="get" action="registered.php">                           <?php //註冊資料表單?>
      <font face="DFKai-sb">暱稱:</font>
	                      <input type="text" name="username" size="12"><br/>
      <br/>					  
      <font face="DFKai-sb">電話號碼:</font>
	                      <input type="text" name="phone" size="10"><br/>
      <br/>		
	  <font face="DFKai-sb">設定密碼:</font>
	                      <input type="text" name="password" size="10"><br/>
      <br/>		
      <font face="DFKai-sb">性別:</font>
	                      <input type="radio" name="gender" value="0">男
						  <input type="radio" name="gender" value="1">女<br/>
      <br/>	
      <font face="DFKai-sb">另一伴電話號碼:</font>
	                      <input type="text" name="anophone" size="10"><br/>
      <br/>		  
      <input type="submit" name="registered" value="註冊" >
   </form>						  
						  
</body>
</html>