<?php //使用者註冊判斷?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>使用者註冊</title>
<style>
   body{
	   background-image:url(12345.jpg);
	   background-repeat:no-repeat;
	   background-position:center;
   }
</style>
</head>
<body bgcolor="#e6e6fa" text="#0000cd"> 
<?php
		$username=$_GET["username"]; 
        $phone=$_GET["phone"];
        $gender=$_GET["gender"];
        $anophone=$_GET["anophone"];
        $password=$_GET["password"];
   
     if($username !=""  && $phone !="" && $gender !="" && $anophone !="" && $password !=""){
		$link =@mysqli_connect('localhost','root','1234','meeting');
	    mysqli_query($link,'SET NAMES utf8'); 
        
		$sql = "SELECT * FROM user WHERE phone='$phone'";
		$result = mysqli_query($link,$sql);
		$num=mysqli_num_rows($result);
		
		if($num>0){
			echo "此電話已註冊過，請至登入畫面";
?>                 <form name="login" method="get" action="userlogin.php">  
                   <input type="submit" name="hasregistered" value="前往登入" >   </form><?php    //用戶已註冊跳至登入畫面
		}else{
			$sql1="INSERT INTO user (name,phone,gender,anophone,password) values('$username','$phone','$gender','$anophone','$password')";
			$link =@mysqli_connect('localhost','root','1234','meeting');
		    mysqli_query($link,'SET NAMES utf8');
		    mysqli_query($link,$sql1);					
		    echo "註冊成功，請重新登入~"; 
?>			<form name="login" method="get" action="userlogin.php"> 
            <input type="submit" name="registered" value="前往登入" >   </form><?php    //用戶註冊成功跳至選項畫面	
		}	
	 }else{
		 echo "請確認所有空格都有填入資料";
	 }	 
	  
?>
</body>
</html>