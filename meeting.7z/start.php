<!DOCTYPE html>

<html>
<head>
<meta charset="utf-8"/>
<title>"歡迎來到新人婚禮準備溝通"</title>
</head>

<body bgcolor="#e6e6fa" text="#0000cd">
  
    <h3>歡迎您的到來，是否有來過呢？</h3>
    <input type="submit" name="first" value="第一次使用" onclick="location.href= ('http://localhost:8080/meeting/usregistration.php')"/>  <?php //進入註冊頁面?>
    <br>
    </br>
    <input type="submit" name="twice" value="已使用過" onclick="location.href= ('http://localhost:8080/meeting/userlogin.php')"/>    <?php //進入登入頁面?>

  
</body>