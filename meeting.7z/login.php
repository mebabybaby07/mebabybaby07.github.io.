<?php
   
   $phone=$_GET["phone"]; 
   $password=$_GET["password"];
   session_start();
   
  if($phone !=""  && $password !=""){
	  $link =@mysqli_connect('localhost','root','1234','meeting');
	  mysqli_query($link,'SET NAMES utf8');
	  $sql = "SELECT * FROM user WHERE phone='$phone'";
	  $result = mysqli_query($link,$sql);

	  $num=mysqli_num_rows($result);
	  if($num>0){
		while($row = mysqli_fetch_assoc($result)){	  
            if($row["password"]==$password){
	           $_SESSION["username"]=$row["name"];
			   $_SESSION["userphone"]=$row["phone"];
			   $_SESSION["usergender"]=$row["gender"];
	           header("Location:functionselect.php");	  
            }else{	            
	           echo "<center><font color='red'>";
	           echo "手機號碼或是密碼錯誤";
	           echo "</font>";
			   ?></br><input type="submit" name="relogin" value="重新登入" onclick="location.href= ('http://localhost:8080/meeting/userlogin.php')"/> <?php
	           $_SESSION["login_session"]=false;
	        }
        }  
	 }else{
		echo "查無此手機號"; 
		?></br><input type="submit" name="relogin" value="重新登入" onclick="location.href= ('http://localhost:8080/meeting/userlogin.php')"/> <?php
	 }    
  }else{
	 echo "請填入手機號碼與密碼";
     ?></br><input type="submit" name="relogin" value="重新登入" onclick="location.href= ('http://localhost:8080/meeting/userlogin.php')"/> <?php	 
	 
  }
  
?>